﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace _ParkingSystem
{
    class Car
    {
        public string CarNumber;
        public DateTime InTime;
        public DateTime OutTime;
        public int ParkingTime()
        {
            return (int)(this.OutTime - this.InTime).TotalMinutes;
        }

        public string StateUpdate()
        {
            int parkingTime = ParkingTime();
            string state;
            if (parkingTime > 0) { state = "완료"; return state; }
            else { state = " 주차중"; return state; }
        }
        public string PrintState()
        {
            int parkingTime = ParkingTime();
            string message;
            if (parkingTime >= 0)
            {
                message = string.Format("차번호: [{0}] /// {1}분 주차했습니다", this.CarNumber, parkingTime);
            }
            else
            {
                message = string.Format("차번호: [{0}] /// 주차중입니다.", this.CarNumber);
            }
            return message;
        }
    }
    class Program
    {
        static string[] CarNumList = new string[100];
        static string[] CarTimeList = new string[100];
        static string[] CarStateList = new string[100];
        static int k = 0;
        static void Main(string[] args)
        {


            Console.WriteLine(" 주차관리 프로그램 ");
            while (true)
            {
                Console.WriteLine("항목을 선택해주세요. ");
                Console.WriteLine(" [1] 새 자동차 등록");
                Console.WriteLine(" [2] 주차 중인 자동차 목록");
                Console.WriteLine(" [3] 정산된 자동차 목록");
                Console.WriteLine(" [4] 전체 목록");
                Console.WriteLine(" [5] 총 결산");
                Console.WriteLine(" 다른 키를 입력해 종료");
                string answer = Console.ReadLine();
                switch (answer)
                {
                    case "1": { Console.WriteLine(Enroll()); return; }
                    case "2": { ParkingCar(); return; }
                    case "3": { PaidCar(); return; }
                    case "4": { TotalList(); return; }
                    case "5": { Result(); return; }
                    default: break;
                }
            }
        }

        static string Enroll()
        {

            Car car = new Car();
            Console.WriteLine("차량번호: ");
            car.CarNumber = Console.ReadLine().Trim();
            if (car.CarNumber == null) Console.WriteLine("차량번호를 재대로 입력해주세요.");

            #region 입고
            int[] input = new int[6];
            int i = 0;

            Console.WriteLine("입고시간(yy/mm/dd hr:min:sec): ");
            String answer = Console.ReadLine();
            if (answer == "")
            {
                Console.WriteLine("주차된 차량이 아닙니다.");
                return Enroll();
            }
            else
            {
                String[] InputTime = answer.Split('/', ' ', ':');

                foreach (string p in InputTime)
                {
                    if (false == int.TryParse(p, out input[i]))
                    {
                        Console.WriteLine("정확한 시간을 입력해주세요");
                        return Enroll(); ;
                    }
                    i++;
                }

                car.InTime = new DateTime(input[0], input[1], input[2], input[3], input[4], input[5]);
            }
            #endregion

            #region 출고시간

            int[] output = new int[6];
            i = 0;
            Console.WriteLine("출고시간(yy/mm/dd hr:min:sec): ");
            answer = Console.ReadLine();
            if (answer == "")
            {
                car.OutTime = new DateTime();
            }
            else
            {
                String[] OutputTime = answer.Split('/', ' ', ':');

                foreach (string p in OutputTime)
                {
                    if (false == int.TryParse(p, out output[i]))
                    {
                        Console.WriteLine("정확한 시간을 입력해주세요");
                        return Enroll();
                    }
                    i++;
                }

                car.OutTime = new DateTime(output[0], output[1], output[2], output[3], output[4], output[5]);
            }
            #endregion

            #region 차등록
            CarTimeList[k] = (car.ParkingTime().ToString());
            CarNumList[k] = car.CarNumber;
            CarStateList[k] = car.StateUpdate();
            k += 1; ;
            #endregion

            return car.PrintState();
        }

        static void ParkingCar()
        {
            int k = 0;
            for (int i = 0; i < 100; i++)
            {
                if (CarStateList[i] == "주차중")
                {
                    k++;
                    Console.WriteLine(CarStateList[i]);
                }
            }
            if (k == 0)
            {
                Console.WriteLine("주차 중인 차량이 없습니다.");
            }
        }

        static void PaidCar()
        {
            int k = 0;
            for (int i = 0; i < 100; i++)
            {
                if (CarStateList[i] == "완료")
                {
                    k++;
                    Console.WriteLine(CarStateList[i]);
                }
            }
            if (k == 0)
            {
                Console.WriteLine("정산된 차량이 없습니다.");
            }
        }

        static void TotalList()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("{0}  {1}  {2} ", CarNumList[i], CarStateList[i], CarTimeList[i]);
            }
        }

        static void Result()
        {
            System.Console.WriteLine("주차비 = 주차시간(분) * 20원");
            int money = 0;
            int totalminutes = 0;
            for (int i = 0; i < 100; i++)
            {
                totalminutes = totalminutes + int.Parse(CarTimeList[i]);
            }
            money = totalminutes * 20;
            Console.WriteLine(" 총 주차시간: {0}", totalminutes);
            Console.WriteLine(" 총 수익:{0}", money);
        }
    }
}
